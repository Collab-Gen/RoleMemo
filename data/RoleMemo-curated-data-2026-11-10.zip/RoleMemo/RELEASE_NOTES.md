# Curated public data release

- Added 1,746 persona-conditioned reasoning queries in four categories.
- Added 151 NPC profiles, 151 paired user profiles, and 151 dialogue histories across 23 domains.
- Preserved source identifiers, original field names, and all dialogue strings.
- Included exact schemas, a dependency-free loading example, per-file metadata, SHA-256 checksums, and paper citation metadata.
- This package contains the curated evaluation data. Training backups, checkpoints, API configuration, and experiment logs are not included.
- Licensed the curated dataset files under CC BY-NC 4.0; code and other repository materials retain their own licensing terms.
