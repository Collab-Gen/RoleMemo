# RoleMemo: Curated Public Data

This directory contains the curated public release of RoleMemo for persona-conditioned memory construction and role-playing evaluation. It provides **1,746 reasoning queries**, **151 NPC personas with 151 paired user personas**, and **151 dialogue histories**, organized across 23 domains.

This release is a curated evaluation snapshot. It contains the four reasoning categories listed below; factual-retrieval-only queries are not included. Sample identifiers are preserved from the source and are not consecutive.

| Query category | Stored label | Queries |
|---|---|---:|
| Decision Guidance | 指导决策类 | 1,399 |
| Value Judgment | 价值判断类 | 136 |
| Interpretive Attribution | 解释归因类 | 110 |
| Contradiction Revelation | 揭示矛盾类 | 101 |
| **Total** | | **1,746** |

## Files

```text
data/
├── benchmark/
│   ├── qa.json
│   ├── dialogues/{npc_id}.json
│   └── personas/
│       ├── NPC完整人设/{domain}.json
│       └── User人设/{domain}.json
├── SCHEMA.md
├── load_example.py
└── manifest.json
```

The dataset consists of 198 JSON files totaling 12,224,253 bytes. The QA file, NPC profiles, user profiles, and dialogue filenames cover exactly the same 151 NPC identifiers. A user persona is the interlocutor paired with the corresponding NPC.

Each QA includes a question, a reference answer, two supporting factual fragments, a persona-conditioned insight, and its reasoning category. Dialogue files store the original utterance strings. Most strings use `User:` or `Assistant:` prefixes; consumers should retain raw entries when a prefix is missing or nonstandard. No utterances have been discarded or rewritten in this release packaging.

See [SCHEMA.md](SCHEMA.md) for the exact fields and [load_example.py](load_example.py) for a dependency-free loading example:

```bash
python data/load_example.py
```

The release preserves the original field names, including Chinese persona keys. NPC `id` values are integers, while QA `npc_id` values are strings; normalize them with `str(...)` when joining. Persona records use `content` for their full character description. Some inference tools may require mapping that field to `description` and converting dialogue strings into structured messages.

## Verification

Per-file byte counts, record counts, and SHA-256 digests are in [manifest.json](manifest.json). Checksums for the packaged files are also available in the repository-level `SHA256SUMS` file.

## License

The curated dataset files under `data/benchmark/` are licensed under [Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)](https://creativecommons.org/licenses/by-nc/4.0/). Noncommercial sharing and adaptation are permitted under the license terms, including appropriate attribution, a link to the license, and an indication of changes.

See [DATA_LICENSE](../DATA_LICENSE) for the dataset license notice and full legal text. This dataset license applies only to `data/benchmark/`; it does not change the licenses of repository code, model checkpoints, or other materials.

## Citation

Please cite the original RoleMemo paper, *From Facts to Insights: A Persona-Driven Dual Memory Framework and Dataset for Role-Playing Agents*. Citation metadata is provided in the repository-level `CITATION.cff`.

Paper: https://aclanthology.org/2026.findings-emnlp.270/
