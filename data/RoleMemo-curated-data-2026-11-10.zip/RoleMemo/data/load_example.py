#!/usr/bin/env python3
"""Load the curated snapshot without third-party dependencies."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent / "benchmark"


def load_profiles(folder):
    profiles = {}
    for path in sorted(folder.glob("*.json")):
        for profile in json.loads(path.read_text(encoding="utf-8")):
            key = str(profile["id"])
            if key in profiles:
                raise ValueError(f"Duplicate profile ID: {key}")
            profiles[key] = profile
    return profiles


def as_message(raw):
    """Convert canonical prefixes and preserve every other original entry."""
    prefix, separator, content = raw.partition(":")
    roles = {"User": "user", "Assistant": "assistant"}
    if separator and prefix in roles:
        return {"role": roles[prefix], "content": content.lstrip(), "raw": raw}
    return {"role": None, "content": raw, "raw": raw}


if __name__ == "__main__":
    queries = json.loads((ROOT / "qa.json").read_text(encoding="utf-8"))
    npcs = load_profiles(ROOT / "personas" / "NPC完整人设")
    users = load_profiles(ROOT / "personas" / "User人设")
    query_ids = {row["npc_id"] for row in queries}
    dialogue_ids = {path.stem for path in (ROOT / "dialogues").glob("*.json")}
    assert len(queries) == 1746
    assert len({row["sample_id"] for row in queries}) == 1746
    assert query_ids == set(npcs) == set(users) == dialogue_ids
    assert len(query_ids) == 151

    # Join one query to its two profiles and its unchanged conversation history.
    query = queries[0]
    npc_id = query["npc_id"]
    npc = npcs[npc_id]
    user = users[npc_id]
    history = json.loads((ROOT / "dialogues" / f"{npc_id}.json").read_text(encoding="utf-8"))
    messages = [as_message(utterance) for utterance in history]
    assert len(messages) == len(history)
    print(f"Loaded {len(queries)} queries and {len(npcs)} paired personas.")
    print("All QA, profile, and dialogue identifiers are aligned.")
